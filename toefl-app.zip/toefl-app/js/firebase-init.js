import { initializeApp } from 'https://www.gstatic.com/firebasejs/10.12.0/firebase-app.js';
import { getAuth, createUserWithEmailAndPassword, signInWithEmailAndPassword, signOut, onAuthStateChanged, updateProfile } from 'https://www.gstatic.com/firebasejs/10.12.0/firebase-auth.js';
import { getFirestore, doc, setDoc, getDoc, collection, addDoc, query, where, orderBy, limit, getDocs, serverTimestamp } from 'https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js';

// ── PASTE YOUR FIREBASE CONFIG HERE ──────────────────────────────
const firebaseConfig = {
  apiKey: "AIzaSyA6ufdWM89W-7cP0YDSYADeNsS8dd0kwyA",
  authDomain: "toefl-mock-test.firebaseapp.com",
  projectId: "toefl-mock-test",
  storageBucket: "toefl-mock-test.firebasestorage.app",
  messagingSenderId: "45827846362",
  appId: "1:45827846362:web:ec4111a2d28da88a0475e3",
  measurementId: "G-3091Z60N9T"
};
// ─────────────────────────────────────────────────────────────────

const app = initializeApp(firebaseConfig);
window._fbAuth = getAuth(app);
window._fbDb  = getFirestore(app);
window._fbFns = { createUserWithEmailAndPassword, signInWithEmailAndPassword, signOut, onAuthStateChanged, updateProfile, doc, setDoc, getDoc, collection, addDoc, query, where, orderBy, limit, getDocs, serverTimestamp };

// Boot app once Firebase is ready
onAuthStateChanged(window._fbAuth, user => {
  window._fbUser = user || null;
  if(window._fbBootReady) window._fbBootReady(user);
});
