// ===================== FIREBASE AUTH & DASHBOARD =====================
let _authMode = 'signin'; // 'signin' | 'register'

function authToggle() {
 _authMode = _authMode === 'signin' ? 'register' : 'signin';
 document.getElementById('authSubtitle').textContent = _authMode === 'register' ? 'Create your account' : 'Sign in to track your progress';
 document.getElementById('authSubmitBtn').textContent = _authMode === 'register' ? 'Create Account' : 'Sign In';
 document.getElementById('authSwitch').innerHTML = _authMode === 'register'
  ? 'Already have an account? <a onclick="authToggle()">Sign in</a>'
  : 'Don\'t have an account? <a onclick="authToggle()">Create one</a>';
 document.getElementById('authNameField').style.display = _authMode === 'register' ? 'block' : 'none';
 document.getElementById('authErr').style.display = 'none';
}

async function authSubmit() {
 const email = document.getElementById('authEmail').value.trim();
 const pass  = document.getElementById('authPass').value;
 const name  = document.getElementById('authName').value.trim();
 const errEl = document.getElementById('authErr');
 errEl.style.display = 'none';
 if(!email || !pass) { showAuthErr('Please enter your email and password.'); return; }
 const btn = document.getElementById('authSubmitBtn');
 btn.textContent = '…'; btn.disabled = true;
 try {
  const { _fbAuth, _fbFns, _fbDb } = window;
  let cred;
  if(_authMode === 'register') {
   if(!name) { showAuthErr('Please enter a display name.'); btn.textContent='Create Account'; btn.disabled=false; return; }
   cred = await _fbFns.createUserWithEmailAndPassword(_fbAuth, email, pass);
   await _fbFns.updateProfile(cred.user, { displayName: name });
   await _fbFns.setDoc(_fbFns.doc(_fbDb, 'users', cred.user.uid), { name, email, createdAt: _fbFns.serverTimestamp(), testsCount:0, bestScore:0 });
  } else {
   cred = await _fbFns.signInWithEmailAndPassword(_fbAuth, email, pass);
  }
  onUserReady(cred.user);
 } catch(e) {
  const msg = e.code === 'auth/user-not-found' ? 'No account found with this email.' :
              e.code === 'auth/wrong-password'  ? 'Incorrect password.' :
              e.code === 'auth/email-already-in-use' ? 'Email already in use.' :
              e.code === 'auth/weak-password'   ? 'Password must be at least 6 characters.' :
              e.code === 'auth/invalid-email'   ? 'Invalid email address.' : e.message;
  showAuthErr(msg);
  btn.textContent = _authMode === 'register' ? 'Create Account' : 'Sign In';
  btn.disabled = false;
 }
}

function authGuest() {
 window._fbUser = null;
 onUserReady(null);
}

function showAuthErr(msg) {
 const el = document.getElementById('authErr');
 el.textContent = msg; el.style.display = 'block';
}

async function authLogout() {
 if(window._fbAuth) await window._fbFns.signOut(window._fbAuth);
 window._fbUser = null;
 location.reload();
}

function onUserReady(user) {
 window._fbUser = user;
 updateWelcomeNav();
 showScreen('screenWelcome');
}

function updateWelcomeNav() {
 const user = window._fbUser;
 const sbUser = document.getElementById('sbUser');
 const signoutBtn = document.getElementById('sbSignout');
 const streakBadge = document.getElementById('streakBadge');
 const xpBadge = document.getElementById('xpBadge');
 if(!sbUser) return;
 if(user) {
  const label = user.displayName || user.email || 'Student';
  const initials = label.slice(0,2).toUpperCase();
  sbUser.innerHTML = `<div class="sb-avatar">${initials}</div><div><div class="sb-user-name">${label}</div><div class="sb-user-sub">TOEFL Candidate</div></div>`;
  if(signoutBtn) signoutBtn.style.display = '';
  loadHeaderStats(user);
 } else {
  sbUser.innerHTML = `<div class="sb-avatar">?</div><div><div class="sb-user-name">Guest</div><div class="sb-user-sub" style="cursor:pointer;color:var(--accent);font-weight:700;" onclick="showScreen('screenAuth')">Sign in →</div></div>`;
  if(signoutBtn) signoutBtn.style.display = 'none';
  if(streakBadge) streakBadge.textContent = '🔥 0 tests';
  if(xpBadge) xpBadge.textContent = '⚡ 0 pts';
 }
}

// Pull testsCount / bestScore for the header badges (repurposed as a lightweight "streak/XP" pair)
async function loadHeaderStats(user) {
 const streakBadge = document.getElementById('streakBadge');
 const xpBadge = document.getElementById('xpBadge');
 try {
  const { _fbDb, _fbFns } = window;
  const snap = await _fbFns.getDoc(_fbFns.doc(_fbDb, 'users', user.uid));
  const d = snap.exists() ? snap.data() : {};
  if(streakBadge) streakBadge.textContent = `🔥 ${d.testsCount||0} tests`;
  if(xpBadge) xpBadge.textContent = `⚡ ${d.bestScore||0} pts`;
 } catch(e) { console.warn('Could not load header stats:', e); }
}

// Save results to Firestore after a test (or single-module practice session)
async function saveTestResult(readScore, listenScore, writeScore, aiData) {
 const user = window._fbUser;
 if(!user) return;
 const { _fbDb, _fbFns } = window;
 const includedNumeric=[readScore,listenScore,writeScore].filter(v=>v!=null);
 const total = includedNumeric.reduce((a,b)=>a+b,0);
 const testTitle = allTests[selectedTestIdx].title;
 const isPractice = !!practiceMode;
 try {
  await _fbFns.addDoc(_fbFns.collection(_fbDb, 'results'), {
   uid: user.uid,
   userName: user.displayName || user.email,
   testIdx: selectedTestIdx,
   testTitle,
   isPractice, moduleName: isPractice ? sections[0]?.name : null,
   readScore: readScore??null, listenScore: listenScore??null, writeScore: writeScore??null, total,
   emailScore: aiData?.emailScore ?? null,
   discScore:  aiData?.discScore  ?? null,
   tips: aiData?.overallTips ?? [],
   createdAt: _fbFns.serverTimestamp()
  });
  // Update user best score — only full mock tests count toward the leaderboard best score
  if(!isPractice){
   const userRef = _fbFns.doc(_fbDb, 'users', user.uid);
   const snap = await _fbFns.getDoc(userRef);
   const prev = snap.exists() ? (snap.data().bestScore || 0) : 0;
   await _fbFns.setDoc(userRef, { bestScore: Math.max(prev, total), testsCount: (snap.data()?.testsCount||0)+1 }, { merge:true });
   loadHeaderStats(user);
  }
 } catch(e) { console.warn('Save result failed:', e); }
}

// ── DASHBOARD ────────────────────────────────────────────────────
let _dashCurrentTab = 'history';

function openDash() {
 setDashTabUI('progress', document.querySelector('.sb-item[data-tab=progress]'));
}

function dashTab(tab, el) {
 _dashCurrentTab = tab;
 document.querySelectorAll('.dash-tab').forEach(t=>t.classList.remove('active'));
 el.classList.add('active');
 if(tab === 'history') loadHistory();
 else loadLeaderboard();
}

async function loadHistory() {
 const user = window._fbUser;
 const el = document.getElementById('dashContent');
 if(!user) { el.innerHTML=`<div class="empty-state"><div class="es-icon">🔒</div><p>Sign in to see your test history.</p></div>`; return; }
 el.innerHTML=`<div class="empty-state"><div class="es-icon">⏳</div><p>Loading your history…</p></div>`;
 try {
  const { _fbDb, _fbFns } = window;
  const q = _fbFns.query(_fbFns.collection(_fbDb,'results'), _fbFns.where('uid','==',user.uid), _fbFns.limit(20));
  const snap = await _fbFns.getDocs(q);
  if(snap.empty) { el.innerHTML=`<div class="empty-state"><div class="es-icon">📋</div><p>No tests completed yet. Take a test to see your history!</p></div>`; return; }
  // Sort client-side by date descending
  const docs = [];
  snap.forEach(d=>docs.push(d.data()));
  docs.sort((a,b)=>{ const ta=a.createdAt?.seconds||0, tb=b.createdAt?.seconds||0; return tb-ta; });
  let html='';
  docs.forEach(r=>{
   const date=r.createdAt?.toDate ? r.createdAt.toDate().toLocaleDateString('en-GB',{day:'numeric',month:'short',year:'numeric'}) : 'Recently';
   const practiceTag = r.isPractice ? `<span style="font-size:.65rem;font-weight:700;background:rgba(232,163,61,.15);color:var(--gold);padding:2px 8px;border-radius:20px;margin-left:8px;text-transform:uppercase;letter-spacing:.5px;">${r.moduleName||'Practice'} only</span>` : '';
   html+=`<div class="hist-card">
    <div class="hist-info">
     <div class="hi-title">Test ${r.testIdx+1}: ${r.testTitle||''}${practiceTag}</div>
     <div class="hi-date">${date}</div>
    </div>
    <div class="hist-scores">
     ${r.readScore!=null?`<div class="hist-badge"><div class="hb-val">${r.readScore}</div><div class="hb-lbl">Reading</div></div>`:''}
     ${r.listenScore!=null?`<div class="hist-badge"><div class="hb-val">${r.listenScore}</div><div class="hb-lbl">Listening</div></div>`:''}
     ${r.writeScore!=null?`<div class="hist-badge"><div class="hb-val">${r.writeScore}</div><div class="hb-lbl">Writing</div></div>`:''}
     <div class="hist-badge" style="background:var(--navy);color:white;"><div class="hb-val" style="color:var(--teal);">${r.total??'–'}</div><div class="hb-lbl" style="color:rgba(255,255,255,.5);">Total</div></div>
    </div>
   </div>`;
  });
  el.innerHTML=html;
 } catch(e) { el.innerHTML=`<div class="empty-state"><div class="es-icon">⚠️</div><p>Could not load history: ${e.message}</p></div>`; }
}

async function loadLeaderboard() {
 const el = document.getElementById('dashContent');
 el.innerHTML=`<div class="empty-state"><div class="es-icon">⏳</div><p>Loading leaderboard…</p></div>`;
 try {
  const { _fbDb, _fbFns } = window;
  const q = _fbFns.query(_fbFns.collection(_fbDb,'users'), _fbFns.orderBy('bestScore','desc'), _fbFns.limit(20));
  const snap = await _fbFns.getDocs(q);
  if(snap.empty) { el.innerHTML=`<div class="empty-state"><div class="es-icon">🏆</div><p>No scores yet. Be the first!</p></div>`; return; }
  const medals=['gold','silver','bronze'];
  let html='', rank=1;
  snap.forEach(d=>{
   const u=d.data();
   const rankClass=rank<=3?medals[rank-1]:'';
   const isMe=window._fbUser&&d.id===window._fbUser.uid;
   html+=`<div class="lb-row" style="${isMe?'border-color:var(--teal);background:#f0fdf9;':''}">
    <div class="lb-rank ${rankClass}">#${rank}</div>
    <div>
     <div class="lb-name">${u.name||u.email||'User'} ${isMe?'<span style="font-size:.72rem;background:var(--teal);color:var(--navy);padding:2px 7px;border-radius:20px;font-weight:700;">You</span>':''}</div>
     <div class="lb-tests">${u.testsCount||0} test${u.testsCount===1?'':'s'} completed</div>
    </div>
    <div class="lb-score">${u.bestScore||0}<span style="font-size:.75rem;color:var(--muted);font-weight:400;">/90</span></div>
   </div>`;
   rank++;
  });
  el.innerHTML=html;
 } catch(e) { el.innerHTML=`<div class="empty-state"><div class="es-icon">⚠️</div><p>Could not load leaderboard: ${e.message}</p></div>`; }
}

// Hook into renderAIResults to save
const _origRenderAI = renderAIResults;
renderAIResults = function(readScore, listenScore, ai) {
 _origRenderAI(readScore, listenScore, ai);
 saveTestResult(readScore, listenScore, ai.writingTotal??22, ai); // speakScore handled inside saveTestResult via aiData
};
const _origFallback = showFallbackResults;
showFallbackResults = function(r, l, w, msg) {
 _origFallback(r, l, w, msg);
 saveTestResult(r, l, w, null);
};

// Boot: show auth screen or welcome depending on Firebase state
window._fbBootReady = function(user) {
 if(user) { onUserReady(user); }
 else { updateWelcomeNav(); showScreen('screenAuth'); }
};
// If Firebase module hasn't loaded yet after 3s, go guest
setTimeout(()=>{ if(!window._fbFns){ window._fbUser=null; updateWelcomeNav(); showScreen(document.getElementById('screenAuth')?'screenAuth':'screenWelcome'); } }, 3000);

