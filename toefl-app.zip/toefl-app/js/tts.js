// ===================== SPEECH SYNTHESIS =====================
// ===================== AUDIO ENGINE =====================
// Situation presets: each listening/speaking context gets a different pace & pitch
// so the audio actually sounds appropriate to what's happening (a quick casual
// remark vs. a formal campus announcement vs. a slow academic lecture vs. a
// clearly-enunciated drill sentence for repetition practice).
const TTS_STYLES = {
  statement:    { rate: 0.98, pitch: 1.05 }, // short casual remark (Listen & Choose a Response)
  announcement: { rate: 0.86, pitch: 0.94 }, // formal, steady, PA-system tone
  lecture:      { rate: 0.84, pitch: 0.98 }, // measured academic pace
  drill:        { rate: 0.80, pitch: 1.00 }, // clear, deliberate — for repeat-after-me practice
  dialogueA:    { rate: 0.93, pitch: 0.88 }, // conversation speaker 1 — slightly lower
  dialogueB:    { rate: 0.95, pitch: 1.22 }  // conversation speaker 2 — slightly higher, distinguishable
};

const TTS = (() => {
  let _queue = [];      // queue of {text, rate, pitch, pause}
  let _qIdx = 0;
  let _activeBtn = null;
  let _keepAlive = null;
  let _stopped = false;
  let _voicesReady = false;

  function _getVoice() {
    const vv = window.speechSynthesis.getVoices();
    return vv.find(v => v.lang && v.lang.startsWith('en-') && v.localService) ||
           vv.find(v => v.lang && v.lang.startsWith('en-')) ||
           vv.find(v => v.lang && v.lang.startsWith('en')) || null;
  }

  function _resetBtn(b) {
    if (!b) return;
    b.classList.remove('playing'); b.dataset.speaking = '';
    b.innerHTML = b.classList.contains('listen-btn') ? '▶ Play' : '▶ Play Audio';
  }

  function stop() {
    _stopped = true;
    _queue = []; _qIdx = 0;
    if (_keepAlive) { clearInterval(_keepAlive); _keepAlive = null; }
    window.speechSynthesis.cancel();
    document.querySelectorAll('.play-audio-btn,.listen-btn').forEach(_resetBtn);
    _activeBtn = null;
  }

  // Split text into ~80-word chunks at sentence boundaries to beat Chrome's ~15s cut-off,
  // tagging each chunk with the rate/pitch it should be spoken at.
  function _chunkText(text, rate, pitch) {
    const sentences = text.match(/[^.!?]+[.!?]+/g) || [text];
    const chunks = []; let cur = '';
    for (const s of sentences) {
      if ((cur + s).split(' ').length > 80 && cur) { chunks.push({text:cur.trim(),rate,pitch}); cur = s; }
      else cur += s;
    }
    if (cur.trim()) chunks.push({text:cur.trim(),rate,pitch});
    return chunks.length ? chunks : [{text,rate,pitch}];
  }

  // Split a two-speaker transcript ("Student A: ...\nStudent B: ...") into a queue
  // of turns, alternating voice pitch so each speaker is distinguishable.
  function _buildDialogueQueue(text) {
    const lines = text.split('\n').map(l=>l.trim()).filter(Boolean);
    const speakerRe = /^([A-Za-z][A-Za-z .]{0,20}):\s*(.+)$/;
    const queue = [];
    let toggle = 0;
    const seenSpeakers = {};
    for (const line of lines) {
      const m = line.match(speakerRe);
      if (m) {
        const speaker = m[1].trim();
        if (!(speaker in seenSpeakers)) seenSpeakers[speaker] = Object.keys(seenSpeakers).length % 2;
        const style = seenSpeakers[speaker] === 0 ? TTS_STYLES.dialogueA : TTS_STYLES.dialogueB;
        _chunkText(m[2], style.rate, style.pitch).forEach((c,i)=>queue.push({...c, pause: i===0}));
      } else {
        _chunkText(line, TTS_STYLES.lecture.rate, TTS_STYLES.lecture.pitch).forEach(c=>queue.push(c));
      }
    }
    return queue.length ? queue : _chunkText(text, TTS_STYLES.lecture.rate, TTS_STYLES.lecture.pitch);
  }

  function _speakNext() {
    if (_stopped || _qIdx >= _queue.length) { if (!_stopped) stop(); return; }
    const item = _queue[_qIdx];
    const utter = new SpeechSynthesisUtterance(item.text);
    utter.rate = item.rate || 0.9; utter.pitch = item.pitch != null ? item.pitch : 1.0; utter.volume = 1.0;
    const v = _getVoice(); if (v) utter.voice = v;
    utter.onend = () => { if (!_stopped) { _qIdx++; setTimeout(_speakNext, item.pause ? 260 : 40); } };
    utter.onerror = (e) => { if (e.error !== 'interrupted') stop(); };
    window.speechSynthesis.cancel(); // flush any stuck queue
    window.speechSynthesis.speak(utter);
  }

  function _startEngine(queue, btn) {
    stop();
    _stopped = false;
    _activeBtn = btn || null;
    _queue = queue;
    _qIdx = 0;

    if (btn) {
      btn.dataset.speaking = '1';
      btn.classList.add('playing');
      btn.innerHTML = btn.classList.contains('listen-btn') ? '⏹ Stop' : '⏹ Stop Audio';
    }

    _speakNext();

    // Chrome keepalive: resume every 500ms if paused
    _keepAlive = setInterval(() => {
      if (_stopped) { clearInterval(_keepAlive); _keepAlive = null; return; }
      if (window.speechSynthesis.paused) window.speechSynthesis.resume();
    }, 500);
  }

  function _initVoices(cb) {
    if (_voicesReady || window.speechSynthesis.getVoices().length > 0) {
      _voicesReady = true; cb(); return;
    }
    let fired = false;
    const handler = () => { if (!fired) { fired = true; _voicesReady = true; cb(); } };
    window.speechSynthesis.addEventListener('voiceschanged', handler, { once: true });
    // Fallback: if event never fires within 800ms, proceed anyway
    setTimeout(() => { if (!fired) { fired = true; _voicesReady = true; cb(); } }, 800);
  }

  // style: one of the keys in TTS_STYLES ('statement'|'announcement'|'lecture'|'drill'). isDialogue:
  // when true, `text` is treated as a multi-speaker transcript and voices alternate per speaker.
  function speak(text, btn, style, isDialogue) {
    if (!text || !text.trim()) return;
    // Toggle: clicking same button while playing → stop
    if (btn && btn.dataset.speaking === '1') { stop(); return; }
    _initVoices(() => {
      const queue = isDialogue ? _buildDialogueQueue(text) : (() => {
        const s = TTS_STYLES[style] || TTS_STYLES.statement;
        return _chunkText(text, s.rate, s.pitch);
      })();
      _startEngine(queue, btn);
    });
  }

  // Warm up voices silently on first user interaction
  function warmup() {
    if (_voicesReady) return;
    _initVoices(() => {
      // Speak a silent utterance to unblock AudioContext on iOS/Chrome
      const u = new SpeechSynthesisUtterance(' ');
      u.volume = 0; u.rate = 10;
      window.speechSynthesis.speak(u);
    });
  }

  return { speak, stop, warmup };
})();

function speakText(text, btn, style, isDialogue) { TTS.speak(text, btn, style, isDialogue); }

// Warm up on first tap anywhere on the page
document.addEventListener('click', () => TTS.warmup(), { once: true });

