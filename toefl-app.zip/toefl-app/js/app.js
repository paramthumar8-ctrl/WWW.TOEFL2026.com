// ===================== WELCOME SCREEN INIT =====================
let selectedTestIdx = 0;

function updateHeroForSelectedTest() {
 const title = allTests[selectedTestIdx].title;
 const heroTitle = document.getElementById('heroTestTitle');
 const courseLabel = document.getElementById('courseActiveLabel');
 if(heroTitle) heroTitle.textContent = `Test ${selectedTestIdx+1}: ${title}`;
 if(courseLabel) courseLabel.textContent = `Test ${selectedTestIdx+1}`;
}

function initTestGrid() {
 const g = document.getElementById('testGrid');
 for(let i=0;i<20;i++){
  const b = document.createElement('button');
  b.className = 'test-btn' + (i===0?' selected':'');
  b.textContent = i+1;
  b.title = allTests[i].title;
  b.onclick = () => {
   document.querySelectorAll('.test-btn').forEach(x=>x.classList.remove('selected'));
   b.classList.add('selected');
   selectedTestIdx = i;
   updateHeroForSelectedTest();
   setDashTabUI('today', document.querySelector('.sb-item[data-tab=today]'));
  };
  g.appendChild(b);
 }
 updateHeroForSelectedTest();
}
initTestGrid();

// ===================== DASHBOARD TAB SWITCHING =====================
const _pageTitles = { today:'Dashboard', progress:'My Progress', browse:'Browse Tests' };

function setDashTabUI(tab, el) {
 document.querySelectorAll('.tab-panel').forEach(p=>p.classList.remove('active'));
 const panel = document.getElementById('panel' + tab.charAt(0).toUpperCase() + tab.slice(1));
 if(panel) panel.classList.add('active');

 document.querySelectorAll('.seg-tab').forEach(t=>t.classList.toggle('active', t.dataset.tab===tab));
 document.querySelectorAll('.sb-item[data-tab]').forEach(t=>t.classList.toggle('active', t.dataset.tab===tab));

 const title = document.getElementById('pageTitle');
 if(title) title.textContent = _pageTitles[tab] || 'Dashboard';

 if(tab==='progress' && typeof loadHistory==='function') dashTab('history', document.querySelector('.dash-tab'));
}

// ===================== THEME TOGGLE =====================
function toggleTheme() {
 const cur = document.documentElement.getAttribute('data-theme') === 'dark' ? 'dark' : 'light';
 const next = cur === 'dark' ? 'light' : 'dark';
 document.documentElement.setAttribute('data-theme', next);
 try{ localStorage.setItem('toefl-theme', next); }catch(e){}
 const btn = document.getElementById('themeToggleBtn');
 if(btn) btn.textContent = next === 'dark' ? '🌙' : '☀️';
}
(function initThemeIcon(){
 const btn = document.getElementById('themeToggleBtn');
 if(btn) btn.textContent = document.documentElement.getAttribute('data-theme')==='dark' ? '🌙' : '☀️';
})();

// ===================== LISTEN & REPEAT SETS (Listening module) =====================
const _listenRepeatSets = [
 ["The library opens at eight in the morning.","Please turn off your phone before the lecture starts.","She borrowed three books from the science section.","The biology professor explained how deep-sea fish produce light.","Students must submit their assignments before the deadline.","Many marine organisms use bioluminescence to attract prey."],
 ["The temperature has risen over the past decade.","Recycling helps reduce waste in our communities.","Scientists are studying the effects of melting polar ice.","The university installed solar panels on the main building.","Carbon emissions from vehicles contribute to global warming.","Renewable energy sources include wind, solar, and water power."],
 ["She reviewed her notes before the examination.","Sleeping well helps the brain store new information.","The professor asked students to summarise the reading.","Short-term memory can hold only a limited amount of data.","Repeating information at intervals improves long-term recall.","Stress and fatigue can significantly affect concentration."],
 ["Light cannot escape from a black hole.","The telescope captured images of a distant galaxy.","Scientists use radio waves to study objects in space.","Gravity is the force that holds planets in their orbits.","The research team published their findings last month.","Space exploration has expanded our understanding of the universe."],
 ["Coral reefs support thousands of marine species.","Rising ocean temperatures cause coral to lose its colour.","The student attended a seminar on environmental conservation.","Pollution from rivers can damage coastal ecosystems.","Researchers collected water samples from the reef.","Protecting biodiversity is a global responsibility."],
 ["Scientists can now edit specific genes with precision.","The ethics committee reviewed the research proposal.","New medical treatments are being developed every year.","The lab results were published in a scientific journal.","Students discussed the risks of genetic modification.","Regulations on biotechnology vary between countries."],
 ["The campus reduced its electricity use by twenty percent.","Wind turbines generate power without burning fuel.","The engineering department is building a prototype solar car.","Energy efficiency saves money and reduces pollution.","The city council approved a new clean energy plan.","Fossil fuels are a limited and non-renewable resource."],
 ["The ocean absorbs carbon dioxide from the atmosphere.","Acidic water makes it harder for shellfish to form shells.","Marine biologists monitor pH levels in the sea.","The professor presented data from a ten-year ocean study.","Fishermen have noticed changes in local fish populations.","International agreements aim to reduce ocean pollution."],
 ["The brain can form new connections throughout life.","Learning a new skill strengthens neural pathways.","Regular exercise has been shown to improve brain function.","The student practised the piano for thirty minutes each day.","Habits become automatic after repeated practice over time.","Sleep plays a vital role in memory consolidation."],
 ["Always complete the full course of antibiotics.","Bacteria can develop resistance to certain medications.","The health centre is open from nine to five on weekdays.","Overusing antibiotics has become a global health concern.","Doctors now test for bacterial infections before prescribing.","Good hygiene helps prevent the spread of infections."],
 ["Cities are often warmer than surrounding rural areas.","Trees and parks help cool urban environments naturally.","The bus route was changed due to road construction.","Urban planners design cities to reduce energy consumption.","Green rooftops can lower indoor temperatures significantly.","Air pollution is higher in areas with heavy traffic."],
 ["Computers can now recognise faces in photographs.","Algorithms make decisions based on patterns in data.","The student studied artificial intelligence for her thesis.","Digital privacy is an important topic in modern society.","Machine learning is used in healthcare to detect diseases early.","Bias in training data can lead to unfair outcomes."],
 ["People often make decisions based on emotion rather than logic.","The team leader listened carefully to everyone's opinion.","Confirmation bias causes people to favour familiar ideas.","Critical thinking is an essential skill in academic study.","We tend to overestimate risks that are emotionally vivid.","Self-awareness helps reduce the impact of cognitive biases."],
 ["The Earth's surface is made up of moving tectonic plates.","Earthquakes occur when two plates suddenly shift position.","The geology lecture covered the formation of mountain ranges.","Volcanoes are often found near the boundaries of plates.","Studying past eruptions helps scientists predict future ones.","Some islands were formed entirely by volcanic activity."],
 ["The human gut contains trillions of microorganisms.","A balanced diet supports healthy gut bacteria.","Fermented foods such as yoghurt contain beneficial microbes.","The student read about the link between diet and mood.","Antibiotics can disrupt the natural balance of gut flora.","Researchers are studying how the microbiome affects immunity."],
 ["Planting trees along streets reduces the urban heat effect.","The city introduced a bike-sharing programme last spring.","Public transport reduces the number of cars on the road.","Green spaces improve mental health in urban populations.","The university campus uses rainwater for irrigation.","Sustainable design considers both people and the environment."],
 ["Transparency in algorithms builds trust with users.","The professor raised concerns about privacy and surveillance.","Facial recognition technology is used in airports worldwide.","Ethical guidelines for artificial intelligence are being developed.","Digital literacy is increasingly important for all students.","Students debated the social impact of automation."],
 ["Being aware of your emotions helps you manage stress better.","The workshop focused on communication and active listening.","Empathy means understanding how another person is feeling.","Group projects require cooperation and mutual respect.","Self-regulation is the ability to control your reactions.","Strong emotional intelligence supports effective leadership."],
 ["A volcanic eruption can affect air travel across a continent.","The ash cloud from the eruption lasted for several days.","Scientists use sensors to monitor activity beneath volcanoes.","Communities near volcanoes must have emergency evacuation plans.","Lava flows slowly but can destroy everything in its path.","Some volcanic soil is extremely fertile for growing crops."],
 ["Eating a variety of vegetables supports a diverse microbiome.","Stress can negatively affect the digestive system.","The student kept a food diary to track her eating habits.","Probiotics are live bacteria found in fermented foods.","The gut is sometimes called the body's second brain.","Diet and lifestyle changes can improve gut health over time."]
];

// ===================== BUILD SECTIONS =====================
function buildSections(testIdx) {
 const t = allTests[testIdx];
 return [
  {
   id:'reading',name:'Reading',color:'reading',icon:'📖',time:1620,
   intro:`<div class="section-icon">📖</div><h2>Reading Section</h2><p>This section is <strong>adaptive</strong>. You'll complete two modules. Your performance in Module 1 determines Module 2 difficulty.</p><ul class="task-list"><li><strong>Complete the Words</strong> — Fill in missing letters in academic paragraphs</li><li><strong>Read in Daily Life</strong> — Short non-academic texts with questions</li><li><strong>Read an Academic Text</strong> — Passages with comprehension questions</li></ul><button class="btn-continue" onclick="startSection()">Start Reading →</button>`,
   questions:[
    {type:'complete_words',tag:'Complete the Words',instruction:'Read the paragraph. Fill in the missing letters for the incomplete words.',passage:t.reading.completeWords.passage,blanks:t.reading.completeWords.blanks,answers:[]},
    ...t.reading.daily.map(d=>({type:'daily',tag:'Read in Daily Life',instruction:'Read the text and answer the question.',title:d.title,passage:d.passage,question:d.q,choices:d.choices,answer:d.answer})),
    {type:'academic',tag:'Read an Academic Text',instruction:'Read the passage and answer the questions.',title:t.reading.academic.title,passage:t.reading.academic.passage,questions:t.reading.academic.questions}
   ]
  },
  {
   id:'listening',name:'Listening',color:'listening',icon:'🎧',time:1620,
   intro:`<div class="section-icon">🎧</div><h2>Listening Section</h2><p>Listen to each audio clip by pressing <strong>▶ Play Audio</strong>. Answer the questions after listening.</p><ul class="task-list"><li><strong>Listen and Choose a Response</strong> — Select the best reply to a spoken statement</li><li><strong>Listen to a Conversation</strong> — Campus dialogue with comprehension questions</li><li><strong>Listen to an Announcement</strong> — Campus notice with questions</li><li><strong>Listen to an Academic Talk</strong> — Lecture excerpt with comprehension questions</li></ul><div class="audio-badge">🔊 Audio-only mode — no transcripts shown</div><button class="btn-continue" onclick="startSection()">Start Listening →</button>`,
   questions:[
    ...t.listening.chooseResponse.map(r=>({type:'choose_response',tag:'Listen and Choose a Response',instruction:'Press Play to hear the statement, then choose the most appropriate response.',audio:r.audio,choices:r.choices,answer:r.answer})),
    {type:'conversation',tag:'Listen to a Conversation',instruction:'Press Play to hear the conversation, then answer the questions.',audioTitle:t.listening.conversation.title,transcript:t.listening.conversation.transcript,questions:t.listening.conversation.questions},
    {type:'announcement',tag:'Listen to an Announcement',instruction:'Press Play to hear the announcement, then answer the questions.',audioTitle:t.listening.announcement.title,transcript:t.listening.announcement.transcript,questions:t.listening.announcement.questions},
    {type:'academic_talk',tag:'Listen to an Academic Talk',instruction:'Press Play to hear the lecture, then answer the questions.',audioTitle:t.listening.academicTalk.title,transcript:t.listening.academicTalk.transcript,questions:t.listening.academicTalk.questions}
   ]
  },
  {
   id:'writing',name:'Writing',color:'writing',icon:'✍️',time:1380,
   intro:`<div class="section-icon">✍️</div><h2>Writing Section</h2><p>You have <strong>23 minutes</strong> for three writing tasks. Focus on clarity, grammar, and appropriate tone.</p><ul class="task-list"><li><strong>Build a Sentence</strong> — Arrange words into a grammatically correct sentence</li><li><strong>Write an Email</strong> — 7 minutes · 60–120 words</li><li><strong>Academic Discussion</strong> — 10 minutes · minimum 100 words</li></ul><button class="btn-continue" onclick="startSection()">Start Writing →</button>`,
   questions:[
    ...t.writing.buildSentences.map((b,i)=>({type:'build_sentence',tag:'Build a Sentence',instruction:'Arrange the words below into a correct, meaningful sentence.',context:b.context||b.c,words:b.words||b.w,answer:b.answer||b.a})),
    {type:'write_email',tag:'Write an Email',instruction:'You have 7 minutes. Write a short email (approximately 60–120 words) responding to the following situation.',prompt:t.writing.email.prompt,minWords:t.writing.email.minWords},
    {type:'academic_discussion',tag:'Academic Discussion',instruction:'You have 10 minutes. Write a response to the academic discussion below. Your post should be at least 100 words.',prompt:t.writing.discussion.prompt,minWords:t.writing.discussion.minWords}
   ]
  },
  {
   id:'speaking',name:'Speaking',color:'speaking',icon:'🎙️',time:480,
   intro:`<div class="section-icon">🎙️</div><h2>Speaking Section</h2><p>You have <strong>8 minutes</strong> for two speaking tasks. Press <strong>▶ Play</strong> to hear each sentence, then record your response using the microphone button.</p><ul class="task-list"><li><strong>Listen &amp; Repeat</strong> — Hear 6 sentences and repeat them accurately (moved here from Listening)</li><li><strong>Simulated Interview</strong> — Answer 4 questions on a topic (45 sec each)</li></ul><div class="audio-badge">🔊 Real audio playback for each sentence</div><button class="btn-continue" onclick="startSection()">Start Speaking →</button>`,
   questions:[
    {type:'listen_repeat',tag:'Listen & Repeat',instruction:'Press ▶ Play to hear each sentence, then click the microphone to record your repetition.',sentences:t.speaking.sentences},
    {type:'interview',tag:'Simulated Interview',instruction:'Answer the following questions about the topic. You have 45 seconds for each answer. No preparation time is given.',topic:t.speaking.interview.topic,questions_list:t.speaking.interview.questions}
   ]
  }
 ];
}

// ===================== STATE =====================
let sections=[], currentSectionIdx=0, timerInterval=null, sectionTimeLeft=0;
let flatQuestions=[], qPointer=0;
// Store responses for AI scoring
const testResponses = { emailText:'', discText:'', emailPrompt:'', discPrompt:'', speakingData:null };
// Store MCQ scores per section
const mcqScores = { reading:{correct:0,total:0,expected:0}, listening:{correct:0,total:0,expected:0}, writing:{correct:0,total:0,expected:0} };

// MCQ types that should be counted toward score
const MCQ_TYPES = ['daily','academic','choose_response','conversation','announcement','academic_talk'];

function showScreen(id) {
 document.querySelectorAll('.screen').forEach(s=>s.classList.remove('active'));
 document.getElementById(id).classList.add('active');
 window.scrollTo(0, 0);
 document.body.style.background = id==='screenAuth' ? 'var(--navy)' : id==='screenWelcome' ? 'var(--paper)' : 'var(--bg)';
 document.documentElement.style.overflow = '';
 document.body.style.overflow = '';
}

// practiceMode === null -> full 4-section exam. Otherwise the id of a single module ('reading'|'listening'|'writing'|'speaking')
let practiceMode = null;

function startTest() {
 practiceMode = null;
 sections = buildSections(selectedTestIdx);
 resetTestState();
 document.getElementById('mainHeader').style.display='flex';
 showSectionIntro(0);
}

function startModulePractice(moduleId) {
 practiceMode = moduleId;
 sections = buildSections(selectedTestIdx).filter(s=>s.id===moduleId);
 resetTestState();
 document.getElementById('mainHeader').style.display='flex';
 showSectionIntro(0);
}

function resetTestState() {
 Object.keys(testResponses).forEach(k=>{ testResponses[k] = k==='speakingData' ? null : ''; });
 Object.keys(mcqScores).forEach(k=>{mcqScores[k].correct=0;mcqScores[k].total=0;mcqScores[k].expected=0;});
 Object.keys(adaptiveScore).forEach(k=>adaptiveScore[k]=[]);
 buildScore=0; buildAttempts=0;
}

function showSectionIntro(idx) {
 TTS.stop();
 currentSectionIdx=idx;
 const sec=sections[idx];
 document.getElementById('headerSection').textContent=sec.name+' — Introduction';
 stopTimer();
 document.getElementById('introContent').innerHTML=sec.intro;
 showScreen('screenIntro');
}

// ===================== ADAPTIVE SCORING =====================
const adaptiveScore = { reading:[], listening:[], writing:[] };
let buildScore=0, buildAttempts=0;

function startSection() {
 const sec=sections[currentSectionIdx];
 flatQuestions=buildFlatQuestions(sec);
 qPointer=0; sectionTimeLeft=sec.time;
 // Reset adaptive tracking for this section
 if(adaptiveScore[sec.id] !== undefined) adaptiveScore[sec.id]=[];
 buildScore=0; buildAttempts=0;
 // Count total scoreable MCQ questions for this section
 if(mcqScores[sec.id] !== undefined){
  mcqScores[sec.id].correct=0;
  mcqScores[sec.id].total=0;
  mcqScores[sec.id].expected = flatQuestions.filter(q=>MCQ_TYPES.includes(q.type)).length;
 }
 startTimer(); renderQuestion();
}

function buildFlatQuestions(sec) {
 const flat=[];
 sec.questions.forEach(q=>{
  if(['academic','conversation','announcement','academic_talk'].includes(q.type)){
   q.questions.forEach((sq,i)=>flat.push({...q,subQ:sq,subQIdx:i,isFirst:i===0}));
  } else flat.push({...q,isFirst:true});
 });
 return flat;
}

function getAdaptiveBand(scores) {
 if(!scores||scores.length===0) return 'standard';
 const pct = scores.reduce((a,b)=>a+b,0)/scores.length;
 return pct >= 0.67 ? 'high' : pct >= 0.34 ? 'standard' : 'low';
}

function getAdaptiveNotice(sec, q) {
 const id = sec.id;
 // Reading: Module 1 = complete_words + daily | Module 2 = academic
 if(id==='reading'){
  if(q.type==='complete_words' && q.isFirst && qPointer===0)
   return `<div class="adaptive-notice">⚡ <div><strong>Adaptive Module 1</strong> — Complete Words &amp; Daily Reading. Your score here determines Module 2 difficulty.</div></div>`;
  if(q.type==='academic' && q.isFirst){
   const band=getAdaptiveBand(adaptiveScore.reading);
   const label=band==='high'?'🔴 High Difficulty':band==='low'?'🟢 Standard Difficulty':'🟡 Medium Difficulty';
   const msg=band==='high'?'Strong Module 1 performance — you have been placed in the higher-difficulty academic reading module.':
             band==='low'?'Your Module 1 score places you in the standard academic reading module. Focus carefully.':
             'Good Module 1 performance — you are in the medium-difficulty academic reading module.';
   return `<div class="adaptive-notice">⚡ <div><strong>Adaptive Module 2 — ${label}</strong><br><span style="font-weight:400;font-size:.85rem;">${msg}</span></div></div>`;
  }
 }
 // Listening: Module 1 = choose_response | Module 2 = conversation/announcement/lecture
 if(id==='listening'){
  if(q.type==='choose_response' && q.isFirst && qPointer===0)
   return `<div class="adaptive-notice">⚡ <div><strong>Adaptive Module 1</strong> — Listen &amp; Choose a Response. Your score sets the difficulty for Module 2.</div></div>`;
  if((q.type==='conversation') && q.isFirst){
   const band=getAdaptiveBand(adaptiveScore.listening);
   const label=band==='high'?'🔴 High Difficulty':band==='low'?'🟢 Standard Difficulty':'🟡 Medium Difficulty';
   const msg=band==='high'?'Excellent Module 1 responses — you are now in the higher-difficulty extended listening module.':
             band==='low'?'You have been placed in the standard extended listening module.':
             'Good Module 1 performance — you are in the medium-difficulty extended listening module.';
   return `<div class="adaptive-notice">⚡ <div><strong>Adaptive Module 2 — ${label}</strong><br><span style="font-weight:400;font-size:.85rem;">${msg}</span></div></div>`;
  }
 }
 // Writing: Module 1 = build_sentence | Module 2 = email/discussion
 if(id==='writing'){
  if(q.type==='build_sentence' && qPointer===0)
   return `<div class="adaptive-notice">⚡ <div><strong>Adaptive Module 1</strong> — Build a Sentence. Easy → Medium difficulty. Your accuracy is tracked.</div></div>`;
  if(q.type==='write_email'){
   const band=getAdaptiveBand(adaptiveScore.writing);
   const msg=band==='high'?'Strong sentence building — you are ready for the extended writing tasks.':
             band==='low'?'Take extra care with grammar and sentence structure in your email and discussion.':
             'Good effort — focus on clear, well-structured writing in Module 2.';
   return `<div class="adaptive-notice">⚡ <div><strong>Adaptive Module 2 — Extended Writing</strong><br><span style="font-weight:400;font-size:.85rem;">${msg}</span></div></div>`;
  }
 }
 return '';
}

function renderQuestion() {
 TTS.stop();
 const sec=sections[currentSectionIdx];
 document.getElementById('headerSection').textContent=sec.name+' — Question '+(qPointer+1)+'/'+flatQuestions.length;
 const q=flatQuestions[qPointer];
 const pct=Math.round((qPointer/flatQuestions.length)*100);
 let html=`<div class="q-meta"><span class="q-tag ${sec.color}">${q.tag}</span><span class="q-num">Question ${qPointer+1} of ${flatQuestions.length}</span></div><div class="progress-bar"><div class="progress-fill" style="width:${pct}%"></div></div>`;
 html += getAdaptiveNotice(sec, q);
 html+=renderQBody(q,sec);
 document.getElementById('qContent').innerHTML=html;
 showScreen('screenQ');
 attachQHandlers(q);
}

function renderQBody(q,sec) {
 switch(q.type){
  case 'complete_words': return renderCompleteWords(q);
  case 'daily': return renderDaily(q,sec);
  case 'academic': return renderAcademicSub(q);
  case 'choose_response': return renderChooseResponse(q);
  case 'conversation': case 'announcement': case 'academic_talk': return renderListeningGroup(q);
  case 'build_sentence': return renderBuildSentence(q);
  case 'write_email': return renderEmail(q);
  case 'academic_discussion': return renderDiscussion(q);
  case 'listen_repeat': return renderListenRepeat(q);
  case 'listen_repeat_listen': return renderListenRepeatListen(q);
  case 'interview': return renderInterview(q);
  default: return '<p>Unknown question type.</p>';
 }
}

function renderCompleteWords(q) {
 let passageHtml=q.passage.replace(/(pl___|ef___|con___)/g,(match)=>`<input class="fill-input" type="text" data-blank="${match}" placeholder="...">`);
 return `<p style="font-size:.9rem;color:var(--muted);margin-bottom:12px;">${q.instruction}</p><div class="passage-box">${passageHtml}</div><div class="q-nav"><button class="btn-nav secondary" onclick="prevQ()" ${qPointer===0?'disabled':''}>← Back</button><button class="btn-nav" onclick="submitFill()">Next →</button></div>`;
}

function renderDaily(q,sec) {
 const letter=['A','B','C','D'];
 const choices=q.choices.map((c,i)=>`<div class="choice" id="ch${i}" onclick="selectChoice(${i},${q.answer})"><div class="choice-letter">${letter[i]}</div><div>${c}</div></div>`).join('');
 return `<p style="font-size:.9rem;color:var(--muted);margin-bottom:12px;">${q.instruction}</p><div class="passage-box daily"><h3>${q.title}</h3>${(q.passage||'').replace(/\n/g,'<br>')}</div><p style="font-weight:600;margin-bottom:12px;">${q.question}</p><div class="choices">${choices}</div><div class="q-nav"><button class="btn-nav secondary" onclick="prevQ()" ${qPointer===0?'disabled':''}>← Back</button><button class="btn-nav" id="btnNext" onclick="nextQ()" disabled>Next →</button></div>`;
}

function renderAcademicSub(q) {
 const sq=q.subQ; const letter=['A','B','C','D'];
 const choices=sq.choices.map((c,i)=>`<div class="choice" id="ch${i}" onclick="selectChoice(${i},${sq.answer})"><div class="choice-letter">${letter[i]}</div><div>${c}</div></div>`).join('');
 const passageHtml=q.isFirst?`<div class="passage-box academic"><h3>${q.title}</h3>${q.passage.replace(/\n/g,'<br>')}</div>`:`<div class="passage-box academic" style="font-style:italic;font-size:.85rem;color:var(--muted);">↑ Refer to the passage: <strong>${q.title}</strong></div>`;
 return `<p style="font-size:.9rem;color:var(--muted);margin-bottom:12px;">${q.instruction}</p>${passageHtml}<p style="font-weight:600;margin-bottom:12px;">${sq.q}</p><div class="choices">${choices}</div><div class="q-nav"><button class="btn-nav secondary" onclick="prevQ()" ${qPointer===0?'disabled':''}>← Back</button><button class="btn-nav" id="btnNext" onclick="nextQ()" disabled>Next →</button></div>`;
}

function renderChooseResponse(q) {
 const letter=['A','B','C','D'];
 const choices=q.choices.map((c,i)=>`<div class="choice" id="ch${i}" onclick="selectChoiceResp(${i},${q.answer})"><div class="choice-letter">${letter[i]}</div><div>${c}</div></div>`).join('');
 const safeAudio=q.audio.replace(/&/g,'&amp;').replace(/"/g,'&quot;');
 return `<p style="font-size:.9rem;color:var(--muted);margin-bottom:12px;">${q.instruction}</p><div class="audio-player"><div class="ap-icon">🔊</div><h3>Listen to the Statement</h3><p>Press play to hear the statement, then select the best response.</p><div class="audio-controls"><button class="play-audio-btn" data-speak="${safeAudio}" onclick="speakText(this.dataset.speak,this,'statement')">▶ Play Audio</button></div></div><p style="font-weight:600;margin-bottom:12px;">Choose the most appropriate response:</p><div class="choices">${choices}</div><div class="q-nav"><button class="btn-nav secondary" onclick="prevQ()" ${qPointer===0?'disabled':''}>← Back</button><button class="btn-nav" id="btnNext" onclick="nextQ()" disabled>Next →</button></div>`;
}

// Store transcripts for audio playback (avoids inline escaping issues)
const _audioStore = {};
let _audioStoreIdx = 0;

function renderListeningGroup(q) {
 const sq=q.subQ; const letter=['A','B','C','D'];
 const choices=sq.choices.map((c,i)=>`<div class="choice" id="ch${i}" onclick="selectChoice(${i},${sq.answer})"><div class="choice-letter">${letter[i]}</div><div>${c}</div></div>`).join('');
 let audioHtml='';
 if(q.isFirst){
  const storeKey='audio_'+(++_audioStoreIdx);
  const isDialogue = q.type==='conversation';
  const style = q.type==='announcement' ? 'announcement' : q.type==='academic_talk' ? 'lecture' : 'lecture';
  // Conversations keep their line breaks so the engine can split turns between two speakers;
  // announcements & lectures are a single narrator, so they're flattened into one steady stream.
  _audioStore[storeKey] = isDialogue ? (q.transcript||'') : (q.transcript||'').replace(/\n/g,' ');
  audioHtml=`<div class="audio-player"><div class="ap-icon">🎧</div><h3>${q.audioTitle}</h3><p>Press play to hear the audio, then answer each question below.</p><div class="audio-controls"><button class="play-audio-btn" data-store-key="${storeKey}" data-dialogue="${isDialogue?'1':'0'}" data-style="${style}" onclick="speakText(_audioStore[this.dataset.storeKey],this,this.dataset.style,this.dataset.dialogue==='1')">▶ Play Audio</button></div>${isDialogue?'<div style="text-align:center;font-size:.72rem;color:var(--muted);margin-top:8px;font-family:\'DM Mono\',monospace;">🔊 Two alternating voices — one per speaker</div>':''}</div>`;
 } else {
  audioHtml=`<div style="background:var(--bg);border-radius:10px;padding:12px 16px;font-size:.85rem;color:var(--muted);margin-bottom:16px;">↑ Refer to the audio: <strong>${q.audioTitle}</strong></div>`;
 }
 return `<p style="font-size:.9rem;color:var(--muted);margin-bottom:12px;">${q.instruction}</p>${audioHtml}<p style="font-weight:600;margin-bottom:12px;">${sq.q}</p><div class="choices">${choices}</div><div class="q-nav"><button class="btn-nav secondary" onclick="prevQ()" ${qPointer===0?'disabled':''}>← Back</button><button class="btn-nav" id="btnNext" onclick="nextQ()" disabled>Next →</button></div>`;
}

function renderListenRepeat(q) {
 const sentencesHtml=q.sentences.map((s,i)=>{
  const safeS=s.replace(/&/g,'&amp;').replace(/"/g,'&quot;');
  return `<div style="background:white;border:1px solid var(--border);border-radius:14px;padding:20px 24px;margin-bottom:12px;display:flex;align-items:center;justify-content:space-between;gap:16px;flex-wrap:wrap;">
   <div>
    <div style="font-size:.72rem;text-transform:uppercase;letter-spacing:1px;color:var(--muted);margin-bottom:4px;">Sentence ${i+1} of ${q.sentences.length}</div>
    <div style="font-size:.88rem;color:var(--muted);font-style:italic;">🔊 Press play, then repeat aloud</div>
   </div>
   <div style="display:flex;align-items:center;gap:10px;">
    <button class="listen-btn" data-speak="${safeS}" onclick="speakText(this.dataset.speak,this,'drill')">▶ Play</button>
    <button class="mic-btn" style="width:40px;height:40px;font-size:1.1rem;" onclick="toggleMic(this)">🎙️</button>
   </div>
  </div>`;
 }).join('');
 return `<p style="font-size:.9rem;color:var(--muted);margin-bottom:16px;">${q.instruction}</p>
 <div style="background:rgba(0,212,180,.08);border:1px solid rgba(0,212,180,.25);border-radius:10px;padding:12px 16px;font-size:.85rem;color:var(--teal);font-weight:600;margin-bottom:18px;">🎧 Audio only — listen carefully and repeat each sentence aloud.</div>
 ${sentencesHtml}
 <div class="q-nav"><button class="btn-nav secondary" onclick="prevQ()" ${qPointer===0?'disabled':''}>← Back</button><button class="btn-nav" onclick="nextQ()">Next →</button></div>`;
}

function renderListenRepeatListen(q) {
 const diff=['Easy','Easy','Easy','Medium','Medium','Medium'];
 const diffColor=['var(--green)','var(--green)','var(--green)','var(--gold)','var(--gold)','var(--gold)'];
 const sentencesHtml=q.sentences.map((s,i)=>{
  const safeS=s.replace(/&/g,'&amp;').replace(/"/g,'&quot;');
  const d=diff[i]||'Medium', dc=diffColor[i]||'var(--gold)';
  return `<div style="background:white;border:1px solid var(--border);border-radius:12px;padding:20px 24px;margin-bottom:12px;display:flex;align-items:center;justify-content:space-between;gap:16px;flex-wrap:wrap;">
   <div style="flex:1;min-width:0;">
    <div style="display:flex;align-items:center;gap:10px;margin-bottom:6px;">
     <span style="font-size:.72rem;font-weight:700;text-transform:uppercase;letter-spacing:.8px;color:var(--muted);">Sentence ${i+1}</span>
     <span style="font-size:.7rem;font-weight:700;padding:2px 9px;border-radius:20px;background:${dc}22;color:${dc};border:1px solid ${dc}66;">${d}</span>
    </div>
    <div style="font-size:1rem;font-weight:600;color:var(--navy);letter-spacing:.01em;">🔊 Press play to hear this sentence</div>
   </div>
   <button class="listen-btn" data-speak="${safeS}" onclick="speakText(this.dataset.speak,this,'drill')" style="white-space:nowrap;flex-shrink:0;">▶ Play</button>
  </div>`;
 }).join('');
 return `<p style="font-size:.9rem;color:var(--muted);margin-bottom:16px;">${q.instruction}</p>
 <div style="background:rgba(0,212,180,.08);border:1px solid rgba(0,212,180,.25);border-radius:10px;padding:12px 16px;font-size:.85rem;color:var(--teal);font-weight:600;margin-bottom:18px;">🎧 Audio only — listen carefully and repeat each sentence aloud after it plays.</div>
 ${sentencesHtml}
 <div class="q-nav"><button class="btn-nav secondary" onclick="prevQ()" ${qPointer===0?'disabled':''}>← Back</button><button class="btn-nav" onclick="nextQ()">Done — Next Task →</button></div>`;
}

function renderInterview(q) {
 const qHtml=q.questions_list.map((qs,i)=>`
  <div style="background:white;border:1px solid var(--border);border-radius:14px;padding:22px 24px;margin-bottom:16px;">
   <div style="font-size:.72rem;text-transform:uppercase;letter-spacing:1px;color:var(--muted);margin-bottom:8px;">Question ${i+1} of ${q.questions_list.length} · 45 seconds</div>
   <p style="font-weight:600;color:var(--navy);margin-bottom:16px;line-height:1.5;">${qs}</p>
   <div style="display:flex;align-items:center;gap:12px;">
    <button class="mic-btn" style="width:44px;height:44px;font-size:1.2rem;" onclick="toggleMic(this)">🎙️</button>
    <div style="font-size:.82rem;color:var(--muted);">No preparation time. Speak naturally for up to 45 seconds.</div>
   </div>
  </div>`).join('');
 return `<p style="font-size:.9rem;color:var(--muted);margin-bottom:12px;">${q.instruction}</p>
  <div class="passage-box" style="border-left:4px solid var(--gold);margin-bottom:20px;font-weight:600;">${q.topic}</div>
  ${qHtml}
  <div class="q-nav"><button class="btn-nav secondary" onclick="prevQ()" ${qPointer===0?'disabled':''}>← Back</button><button class="btn-nav" onclick="nextQ()">Next →</button></div>`;
}

function renderBuildSentence(q) {
 // Shuffle a copy of the words (Fisher-Yates)
 const shuffled=[...q.words.map((w,i)=>({w,i}))];
 for(let k=shuffled.length-1;k>0;k--){const j=Math.floor(Math.random()*(k+1));[shuffled[k],shuffled[j]]=[shuffled[j],shuffled[k]];}
 const wordsHtml=shuffled.map(({w,i})=>`<div class="word-chip" id="wchip${i}" onclick="placeWord('${w.replace(/'/g,"\\'")}',${i})">${w}</div>`).join('');
 const diff=q.difficulty||'easy';
 const diffColor=diff==='medium'?'var(--gold)':'var(--green)';
 const diffBadge=`<span style="font-size:.72rem;font-weight:700;padding:2px 10px;border-radius:20px;background:${diffColor}22;color:${diffColor};border:1px solid ${diffColor}66;margin-left:10px;">${diff.charAt(0).toUpperCase()+diff.slice(1)}</span>`;
 return `<p style="font-size:.9rem;color:var(--muted);margin-bottom:12px;">${q.instruction}${diffBadge}</p><div class="passage-box" style="border-left:4px solid var(--green);font-size:.88rem;color:var(--muted);">Context: ${q.context}</div><p style="font-weight:600;margin-bottom:12px;">Arrange these words into a sentence:</p><div class="word-bank" id="wordBank">${wordsHtml}</div><p class="build-hint">Your sentence:</p><div class="sentence-build" id="sentenceBuild"><span style="color:var(--muted);font-size:.85rem;" id="buildPlaceholder">Tap words above to build your sentence.</span></div><div class="q-nav"><button class="btn-nav secondary" onclick="prevQ()" ${qPointer===0?'disabled':''}>← Back</button><button class="btn-nav" onclick="submitBuild('${q.answer.replace(/'/g,"\\'")}')">Next →</button></div>`;
}

function renderEmail(q) {
 return `<p style="font-size:.9rem;color:var(--muted);margin-bottom:12px;">${q.instruction}</p><div class="writing-prompt"><strong>Situation:</strong><br>${q.prompt.replace(/\n/g,'<br>')}</div><textarea class="writing-area" id="emailText" placeholder="Write your email here..." oninput="updateWordCount('emailText','emailWC')"></textarea><div class="word-count" id="emailWC">0 words</div><div class="q-nav"><button class="btn-nav secondary" onclick="prevQ()" ${qPointer===0?'disabled':''}>← Back</button><button class="btn-nav" onclick="submitWriting('emailText',${q.minWords})">Next →</button></div>`;
}

function renderDiscussion(q) {
 return `<p style="font-size:.9rem;color:var(--muted);margin-bottom:12px;">${q.instruction}</p><div class="writing-prompt">${q.prompt.replace(/\n/g,'<br>')}</div><textarea class="writing-area" style="min-height:240px;" id="discText" placeholder="Write your discussion post here..." oninput="updateWordCount('discText','discWC')"></textarea><div class="word-count" id="discWC">0 words</div><div class="q-nav"><button class="btn-nav secondary" onclick="prevQ()" ${qPointer===0?'disabled':''}>← Back</button><button class="btn-nav" onclick="submitWriting('discText',${q.minWords})">Next →</button></div>`;
}

function toggleTranscript(btn) {
 const box=btn.nextElementSibling;
 if(box.style.display==='block'){box.style.display='none';btn.textContent='Show Transcript ▼';}
 else{box.style.display='block';btn.textContent='Hide Transcript ▲';}
}
function toggleMic(btn) {
 if(btn.classList.contains('recording')){btn.classList.remove('recording');btn.textContent='🎙️';}
 else{btn.classList.add('recording');btn.textContent='⏹';}
}


function selectChoice(selected, correct) {
 for(let i=0;i<4;i++){
  const el=document.getElementById('ch'+i); if(!el) continue;
  el.classList.remove('selected','correct','wrong');
  if(i===selected) el.classList.add(selected===correct?'correct':'wrong');
  else if(i===correct&&selected!==correct) el.classList.add('correct');
  el.onclick=null;
 }
 const btn=document.getElementById('btnNext'); if(btn) btn.disabled=false;
 // Track score for adaptive logic AND MCQ totals
 const sec=sections[currentSectionIdx];
 if(sec && adaptiveScore[sec.id] !== undefined){
  adaptiveScore[sec.id].push(selected===correct ? 1 : 0);
 }
 if(sec && mcqScores[sec.id] !== undefined){
  mcqScores[sec.id].total++;
  if(selected===correct) mcqScores[sec.id].correct++;
 }
}
function selectChoiceResp(selected, correct) { selectChoice(selected, correct); }

let placedWords=[],placedIndices=[];
function placeWord(word,idx){
 const chip=document.getElementById('wchip'+idx);
 if(chip&&chip.classList.contains('used')) return;
 placedWords.push(word); placedIndices.push(idx);
 if(chip) chip.classList.add('used');
 renderPlaced();
}
function renderPlaced(){
 const box=document.getElementById('sentenceBuild');
 const ph=document.getElementById('buildPlaceholder');
 if(ph) ph.style.display='none';
 if(!box) return;
 box.innerHTML=placedWords.map((w,i)=>`<div class="placed-word" onclick="removeWord(${i})">${w}</div>`).join('');
 if(placedWords.length>0) box.classList.add('has-words');
}
function removeWord(i){
 const idx=placedIndices[i];
 const chip=document.getElementById('wchip'+idx);
 if(chip) chip.classList.remove('used');
 placedWords.splice(i,1); placedIndices.splice(i,1);
 renderPlaced();
}
function submitBuild(answer){
 const built=placedWords.join(' ').toLowerCase().trim().replace(/[?.!]/g,'');
 const correct=answer.toLowerCase().trim().replace(/[?.!]/g,'');
 const isCorrect=built===correct;
 buildAttempts++;
 if(isCorrect) buildScore++;
 adaptiveScore.writing.push(isCorrect ? 1 : 0);
 const q=flatQuestions[qPointer];
 const box=document.getElementById('sentenceBuild');
 if(box){
  box.style.background=isCorrect?'#e8faf1':'#fff0f0';
  box.style.border=`2px solid ${isCorrect?'var(--green)':'var(--red)'}`;
  if(!isCorrect){
   const hint=document.createElement('div');
   hint.style.cssText='margin-top:10px;font-size:.82rem;color:var(--muted);';
   hint.innerHTML=`✅ Correct: <em>${answer}</em>`;
   box.appendChild(hint);
  }
 }
 const delay=isCorrect?1000:1800;
 setTimeout(()=>{placedWords=[];placedIndices=[];nextQ();},delay);
}
function submitFill(){nextQ();}
function attachQHandlers(q){placedWords=[];placedIndices=[];}
function updateWordCount(tid,wid){
 const ta=document.getElementById(tid),wc=document.getElementById(wid);
 if(!ta||!wc) return;
 const count=ta.value.trim().split(/\s+/).filter(w=>w.length>0).length;
 wc.textContent=count+' words';
 wc.style.color=count<(wid==='emailWC'?60:100)?'var(--red)':'var(--green)';
}
function saveLRAndNext(count){
 if(!testResponses.speakingData) testResponses.speakingData={repeatSentences:[],interviewResponses:[]};
 const sentences=[];
 for(let i=0;i<count;i++){
  const text=(document.getElementById('spk_repeat_'+i)||{}).value||'';
  const fluency=+(document.getElementById('spk_r_'+i+'_fluency')||{}).value||3;
  const pronunciation=+(document.getElementById('spk_r_'+i+'_pronunciation')||{}).value||3;
  const grammar=+(document.getElementById('spk_r_'+i+'_grammar')||{}).value||3;
  sentences.push({text,fluency,pronunciation,grammar});
 }
 testResponses.speakingData.repeatSentences=sentences;
 nextQ();
}

function saveInterviewAndNext(count){
 if(!testResponses.speakingData) testResponses.speakingData={repeatSentences:[],interviewResponses:[]};
 const responses=[];
 const sec=sections[currentSectionIdx];
 const q=flatQuestions[qPointer];
 for(let i=0;i<count;i++){
  const text=(document.getElementById('spk_int_'+i)||{}).value||'';
  const fluency=+(document.getElementById('spk_i_'+i+'_fluency')||{}).value||3;
  const vocabulary=+(document.getElementById('spk_i_'+i+'_vocabulary')||{}).value||3;
  const structure=+(document.getElementById('spk_i_'+i+'_structure')||{}).value||3;
  responses.push({question:q.questions_list?.[i]||'',text,fluency,vocabulary,structure});
 }
 testResponses.speakingData.interviewResponses=responses;
 testResponses.speakingData.topic=q.topic||'';
 nextQ();
}

function submitWriting(tid,minWords){
 const ta=document.getElementById(tid); if(!ta){nextQ();return;}
 const count=ta.value.trim().split(/\s+/).filter(w=>w.length>0).length;
 if(count<minWords){
  const wc=document.getElementById(tid==='emailText'?'emailWC':'discWC');
  if(wc){wc.textContent=`⚠ Please write at least ${minWords} words (currently ${count})`;wc.style.color='var(--red)';}
  return;
 }
 // Save for AI scoring
 const q=flatQuestions[qPointer];
 if(tid==='emailText'){testResponses.emailText=ta.value.trim();testResponses.emailPrompt=q.prompt||'';}
 else{testResponses.discText=ta.value.trim();testResponses.discPrompt=q.prompt||'';}
 nextQ();
}

function nextQ(){qPointer++;if(qPointer>=flatQuestions.length)endSection();else renderQuestion();}
function prevQ(){if(qPointer>0){qPointer--;renderQuestion();}}
function endSection(){stopTimer();const nextIdx=currentSectionIdx+1;if(nextIdx<sections.length)showSectionIntro(nextIdx);else showResults();}

function showResults(){
 stopTimer(); TTS.stop();
 document.getElementById('mainHeader').style.display='none';

 // Calculate MCQ-based section scores (0–30 scale per section, TOEFL iBT style)
 function calcSectionScore(secId){
  const d=mcqScores[secId];
  const denom = d.expected > 0 ? d.expected : (d.total > 0 ? d.total : 0);
  if(!d || denom===0) return null;
  return Math.round((d.correct/denom)*30);
 }
 const includedIds = sections.map(s=>s.id);
 const readScore   = includedIds.includes('reading')   ? (calcSectionScore('reading')??22)   : null;
 const listenScore = includedIds.includes('listening') ? (calcSectionScore('listening')??22) : null;

 const testTitle=allTests[selectedTestIdx].title;
 const hasEmail=!!testResponses.emailText;
 const hasDisc=!!testResponses.discText;
 const isPractice = !!practiceMode;
 const needsAI = includedIds.includes('writing');

 const titleText = isPractice ? `${sections[0].name} Module — Practice Complete!` : 'Mock Test Complete!';
 const subText   = isPractice ? `Test ${selectedTestIdx+1}: ${testTitle} · ${sections[0].name} module only` : `Test ${selectedTestIdx+1}: ${testTitle}`;

 function cardFor(id){
  if(id==='reading')   return `<div class="score-item reading"><div class="si-label">📖 Reading</div><div class="si-band" id="siRead">${readScore}/30</div><div class="si-desc" id="siReadDesc">${readScore>=22?'Strong comprehension':readScore>=15?'Good understanding':'Review reading strategies'}</div></div>`;
  if(id==='listening') return `<div class="score-item listening"><div class="si-label">🎧 Listening</div><div class="si-band" id="siListen">${listenScore}/30</div><div class="si-desc" id="siListenDesc">${listenScore>=22?'Good inference & detail recall':listenScore>=15?'Developing skills':'Focus on key details'}</div></div>`;
  if(id==='writing')   return `<div class="score-item writing"><div class="si-label">✍️ Writing</div><div class="si-band" id="siWrite">…</div><div class="si-desc" id="siWriteDesc">AI scoring in progress</div></div>`;
  if(id==='speaking')  return `<div class="score-item speaking"><div class="si-label">🎙️ Speaking</div><div class="si-band" id="siSpeak">–</div><div class="si-desc" id="siSpeakDesc">Practice &amp; self-assess</div></div>`;
  return '';
 }
 const scoreGridHtml = includedIds.map(cardFor).join('');

 const showOverallBand = !isPractice || includedIds.length>1 || needsAI;
 const overallBandHtml = showOverallBand ? `<div class="overall-score">
     <div class="os-label">${needsAI?'Calculating your score…':'Your score'}</div>
     <div class="os-band" id="osBand" style="opacity:${needsAI?'.3':'1'}">${needsAI?'–':(readScore??listenScore??'–')}</div>
     <div class="os-120" id="os120">${needsAI?'':`out of ${includedIds.filter(i=>['reading','listening'].includes(i)).length*30} graded points`}</div>
    </div>` : '';

 const aiPanelHtml = needsAI ? `
    <div style="background:linear-gradient(135deg,rgba(28,110,111,.07),rgba(232,163,61,.07));border:1.5px solid rgba(232,163,61,.3);border-radius:14px;padding:24px 28px;text-align:center;">
     <div style="font-size:1.5rem;margin-bottom:10px;">🤖</div>
     <div style="font-weight:700;color:var(--navy);margin-bottom:6px;">AI Scoring Your Writing…</div>
     <div style="font-size:.88rem;color:var(--muted);" id="aiStatusMsg">Analysing your writing responses against the TOEFL iBT rubric…</div>
     <div style="margin-top:16px;display:flex;justify-content:center;gap:8px;" id="aiDots">
      <span style="width:10px;height:10px;border-radius:50%;background:var(--teal);display:inline-block;animation:pulse 1.2s ease-in-out infinite;"></span>
      <span style="width:10px;height:10px;border-radius:50%;background:var(--teal);display:inline-block;animation:pulse 1.2s ease-in-out .3s infinite;"></span>
      <span style="width:10px;height:10px;border-radius:50%;background:var(--teal);display:inline-block;animation:pulse 1.2s ease-in-out .6s infinite;"></span>
     </div>
    </div>` : (includedIds.includes('speaking') ? `
    <div style="background:rgba(232,163,61,.08);border:1.5px solid rgba(232,163,61,.3);border-radius:14px;padding:22px 26px;text-align:center;">
     <div style="font-size:1.5rem;margin-bottom:8px;">🎙️</div>
     <div style="font-weight:700;color:var(--navy);margin-bottom:6px;">Nice work!</div>
     <div style="font-size:.88rem;color:var(--muted);">Speaking isn't auto-graded — play back your recordings, compare them with the model sentences, and repeat any that felt shaky.</div>
    </div>` : '');

 document.getElementById('resultsContent').innerHTML=`
  <div class="results-card fade-in">
   <div style="font-size:3rem;margin-bottom:16px;">🎓</div>
   <h2>${titleText}</h2>
   <p class="sub">${subText}</p>

   <div id="scoreOverview">
    ${overallBandHtml}
    <div class="score-grid" id="scoreGrid">${scoreGridHtml}</div>
   </div>

   <div id="aiFeedbackArea" style="margin-top:28px;">${aiPanelHtml}</div>

   <div style="display:flex;gap:12px;justify-content:center;flex-wrap:wrap;margin-top:28px;">
    <button class="btn-start" onclick="location.reload()">← Return to Test Menu</button>
   </div>
  </div>`;

 showScreen('screenResults');
 if(needsAI){
  runAIScoring(readScore, listenScore, hasEmail, hasDisc);
 } else if(!includedIds.includes('speaking')){
  saveTestResult(readScore, listenScore, null, null);
 }
}

async function runAIScoring(readScore, listenScore, hasEmail, hasDisc){
 const emailText=testResponses.emailText;
 const discText=testResponses.discText;
 const emailPrompt=testResponses.emailPrompt;
 const discPrompt=testResponses.discPrompt;

 const parts=[];
 if(hasEmail) parts.push(`=== EMAIL TASK ===\nPrompt: ${emailPrompt}\n\nStudent's email:\n${emailText}`);
 if(hasDisc) parts.push(`=== ACADEMIC DISCUSSION ===\nPrompt: ${discPrompt}\n\nStudent's response:\n${discText}`);

 if(!parts.length){
  showFallbackResults(readScore,listenScore,22,'No written or spoken responses submitted.');
  return;
 }

 const prompt=`You are an expert TOEFL iBT examiner. Score the following student responses.

${parts.join('\n\n')}

Respond ONLY with a valid JSON object in this exact format (no markdown, no preamble):
{
  "emailScore": <integer 0-5 or null if no email>,
  "emailFeedback": "<2-3 sentences: what was good + what to improve>",
  "discScore": <integer 0-5 or null if no discussion>,
  "discFeedback": "<2-3 sentences: what was good + what to improve>",
  "writingTotal": <integer 0-30, scaled from the two task scores>,
  "overallTips": ["<tip 1>","<tip 2>","<tip 3>"],
  "strengthSummary": "<one sentence overall strength across all sections>",
  "weaknessSummary": "<one sentence main area to improve overall>"
}

Writing rubric (0–5 per task):
5=Fully addresses task, coherent, accurate; 4=Good with minor errors; 3=Adequate with some errors; 2=Partial/frequent errors; 1=Minimal attempt; 0=Empty/off-topic

Speaking rubric (0–30 total):
Consider typed responses as transcripts of what was said. Factor in self-ratings as supporting evidence.
25-30=Fluent, varied vocab, clear structure, minimal errors
18-24=Generally clear, some hesitation, good vocabulary range
10-17=Understandable but limited, noticeable errors, simple structures
0-9=Difficult to understand, very limited range`;

 try{
  const resp=await fetch('https://api.anthropic.com/v1/messages',{
   method:'POST',
   headers:{'Content-Type':'application/json'},
   body:JSON.stringify({
    model:'claude-sonnet-4-20250514',
    max_tokens:1200,
    messages:[{role:'user',content:prompt}]
   })
  });
  const data=await resp.json();
  const raw=data.content?.find(b=>b.type==='text')?.text||'';
  let parsed;
  try{ parsed=JSON.parse(raw.replace(/```json|```/g,'').trim()); }
  catch(e){ throw new Error('JSON parse failed: '+raw.slice(0,200)); }
  renderAIResults(readScore,listenScore,parsed);
 }catch(err){
  console.error('AI scoring error:',err);
  showFallbackResults(readScore,listenScore,22,'AI scoring unavailable.');
 }
}

function renderAIResults(readScore,listenScore,ai){
 const writeScore=ai.writingTotal??22;
 const includedNumeric=[readScore,listenScore,writeScore].filter(v=>v!=null);
 const denom=includedNumeric.length*30;
 const total=includedNumeric.reduce((a,b)=>a+b,0);
 const cefr=total>=Math.round(denom*.89)?'C1 — Advanced':total>=Math.round(denom*.67)?'B2 — Upper-Intermediate':total>=Math.round(denom*.44)?'B1 — Intermediate':'A2 — Elementary';

 const osBand=document.getElementById('osBand');
 if(osBand){ osBand.textContent=total; osBand.style.opacity='1'; }
 const os120=document.getElementById('os120');
 if(os120) os120.innerHTML=`out of ${denom} graded points &nbsp;·&nbsp; ${cefr}`;
 const siWrite=document.getElementById('siWrite');
 if(siWrite) siWrite.textContent=writeScore+'/30';
 const siWriteDesc=document.getElementById('siWriteDesc');
 if(siWriteDesc) siWriteDesc.textContent=writeScore>=22?'Strong written communication':writeScore>=15?'Developing writing skills':'Focus on task completion & grammar';
 const siSpeak=document.getElementById('siSpeak');
 if(siSpeak){ siSpeak.textContent='–'; document.getElementById('siSpeakDesc').textContent='Practice & self-assess'; }

 const tips=(ai.overallTips||[]).map(t=>`<div class="fb-item"><div class="fb-dot ok"></div><div>${t}</div></div>`).join('');

 const emailBlock=ai.emailScore!=null?`
  <div style="background:white;border:1.5px solid var(--border);border-radius:12px;padding:20px 24px;margin-bottom:14px;">
   <div style="display:flex;align-items:center;gap:12px;margin-bottom:10px;">
    <span style="font-weight:700;color:var(--navy);">✍️ Email Task</span>
    <span style="font-size:1.1rem;font-weight:800;color:${ai.emailScore>=4?'var(--green)':ai.emailScore>=3?'var(--gold)':'var(--red)'};">${ai.emailScore}/5</span>
   </div>
   <p style="font-size:.9rem;color:var(--text);line-height:1.65;margin:0;">${ai.emailFeedback||''}</p>
  </div>`:'';

 const discBlock=ai.discScore!=null?`
  <div style="background:white;border:1.5px solid var(--border);border-radius:12px;padding:20px 24px;margin-bottom:14px;">
   <div style="display:flex;align-items:center;gap:12px;margin-bottom:10px;">
    <span style="font-weight:700;color:var(--navy);">📝 Academic Discussion</span>
    <span style="font-size:1.1rem;font-weight:800;color:${ai.discScore>=4?'var(--green)':ai.discScore>=3?'var(--gold)':'var(--red)'};">${ai.discScore}/5</span>
   </div>
   <p style="font-size:.9rem;color:var(--text);line-height:1.65;margin:0;">${ai.discFeedback||''}</p>
  </div>`:'';

 document.getElementById('aiFeedbackArea').innerHTML=`
  <div class="feedback-list">
   <h4 style="margin-bottom:16px;">🤖 AI Feedback</h4>
   ${emailBlock}${discBlock}
   ${ai.strengthSummary?`<div class="fb-item"><div class="fb-dot good"></div><div><strong>Overall strength:</strong> ${ai.strengthSummary}</div></div>`:''}
   ${ai.weaknessSummary?`<div class="fb-item"><div class="fb-dot needs"></div><div><strong>Priority:</strong> ${ai.weaknessSummary}</div></div>`:''}
   ${tips?`<div style="margin-top:16px;"><strong style="font-size:.85rem;text-transform:uppercase;letter-spacing:.5px;color:var(--muted);">Tips to improve</strong>${tips}</div>`:''}
  </div>`;
}

function showFallbackResults(readScore,listenScore,writeScore,msg){
 const includedNumeric=[readScore,listenScore,writeScore].filter(v=>v!=null);
 const denom=includedNumeric.length*30;
 const total=includedNumeric.reduce((a,b)=>a+b,0);
 const osBand=document.getElementById('osBand');
 if(osBand){ osBand.textContent=total; osBand.style.opacity='1'; }
 const os120=document.getElementById('os120');
 if(os120) os120.textContent=`out of ${denom} graded points`;
 const siWrite=document.getElementById('siWrite');
 if(siWrite && writeScore!=null){ siWrite.textContent=writeScore+'/30'; document.getElementById('siWriteDesc').textContent='Writing estimated'; }
 const siSpeak=document.getElementById('siSpeak');
 if(siSpeak){ siSpeak.textContent='–'; document.getElementById('siSpeakDesc').textContent='Practice & self-assess'; }
 document.getElementById('aiFeedbackArea').innerHTML=`<div style="background:#fff8ec;border:1.5px solid var(--gold);border-radius:12px;padding:18px 22px;font-size:.9rem;color:var(--text);">⚠ ${msg}</div>`;
}

function startTimer(){
 stopTimer(); updateTimerDisplay();
 timerInterval=setInterval(()=>{sectionTimeLeft--;updateTimerDisplay();if(sectionTimeLeft<=0){stopTimer();endSection();}},1000);
}
function stopTimer(){if(timerInterval){clearInterval(timerInterval);timerInterval=null;}}
function updateTimerDisplay(){
 const m=Math.floor(sectionTimeLeft/60),s=sectionTimeLeft%60;
 const str=`⏱ ${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`;
 const el=document.getElementById('headerTimer'); if(!el) return;
 el.textContent=str; el.className='header-timer';
 if(sectionTimeLeft<=60) el.className='header-timer urgent';
 else if(sectionTimeLeft<=180) el.className='header-timer warn';
}

